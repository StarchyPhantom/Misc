﻿//Author: Benjamin Huynh
//File name: Program.cs
//Project name: Pass1
//Creation date: February 15, 2023
//Modified date: February 26, 2023
//Description: A console version of of the hit game "wordle," where the objective is to guess a five letter word
//				with hints of letter position given every guess, as well as showing statistics in regards to the guesses

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Pass1
{
	class Program
	{
		//setup input/output variables
		static StreamWriter outFile;
		static StreamReader inFile;

		//setup random number generator variable
		static Random rng = new Random();

		//menu inputs for the corresponding things
		const string PLAY = "1";
		const string INSTRUCTIONS = "2";
		const string STATS = "3";
		const string RESET_STATS = "7";
		const string EXIT = "0";

		//number of elements in the stats file
		const byte STATS_FILE_LENGTH = 9;

		//length of the target words
		const byte WORD_LENGTH = 5;

		//tries allowed per word
		const byte TRIES = 6;

		//length of the alphabet, & the 3x10 sample used
		const byte ALPHABET_LENGTH = 26;
		const byte ALPHABET_SAMPLE_WIDTH = 10;
		const byte ALPHABET_SAMPLE_HEIGHT = 3;

		//codes corresponding to colours
		const byte GREEN_CODE = 1;
		const byte YELLOW_CODE = 2;
		const byte GRAY_CODE = 3;

		//max length for the bar representing guess distribution 
		const byte MAX_BAR_LENGTH = 10;

		//the alphabet in an array
		static readonly char[] alphabet = new char[26] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
		static void Main(string[] args)
		{
			//2d array represting the worlde grid, storing the characters of the guesses
			char[,] displayGridArray = new char[TRIES, WORD_LENGTH];

			//stores the current attempt
			byte currentTry = 0;

			//store the games played and the streaks
			int gamesPlayed = 0;
			int currentStreak = 0;
			int maximumStreak = 0;

			//array to store number of wins on each guess
			int[] winSpread = new int[TRIES];

			//array to store codes corresponding to colours
			byte[] letterColourCode = new byte[26];
			
			//strings and string array containing the answer and user guesses
			string answerWord = "lavas"; //testing purposes, ignore this ->(vills try with ionic and idiot, try momma, try price with eerie)
			string userInput;
			string[] prevInputs = new string[TRIES];

			//booleans to exit the program and finish the game
			bool exitGame = false;
			bool finishedGame = true;

			//lists to store file data
			List<string> wordleAnswers = new List<string>();
			List<string> wordleExtras = new List<string>();
			List<string> statsIn = new List<string>();

			//read the text files of possible answers
			ReadWordFile("WordleAnswers.txt", wordleAnswers);
			ReadWordFile("WordleExtras.txt", wordleAnswers);
			ReadWordFile("PlayerStats.txt", statsIn);

			//if the file information is correctly formatted/exists, update the variables. it is known where the varibles are
			if (statsIn.Count == STATS_FILE_LENGTH)
			{
				//update the variables with the file data
				gamesPlayed = Convert.ToInt32(statsIn[0]);
				currentStreak = Convert.ToInt32(statsIn[1]);
				maximumStreak = Convert.ToInt32(statsIn[2]);

				//update the array with the file data
				for (int i = 0; i < winSpread.Length; i++)
				{
					//update the index with the file data
					winSpread[i] = Convert.ToInt32(statsIn[i + 3]);
				}
			}

			//clear the screen of any errors catched
			Console.Clear();

			//run the program until he user stops
			while (exitGame == false)
			{
				//run the game until the user wins or loses
				while (finishedGame == false)
				{
					//read the user input and clear the console
					userInput = Console.ReadLine().ToLower();
					Console.Clear();

					//check if the input is 5 letters, if not, prompt user to try again, if yes, check input
					if (userInput.Length == WORD_LENGTH)
					{
						//check if the user already entered that word, else check if the input is a real word
						if (currentTry != 0 && prevInputs.Contains(userInput))
						{
							//tell the user to try another input
							Console.WriteLine("Already tried that word, please try another one");
						}
						else
						{
							//check if the input is a word in the dictionaries, else ask for a new in put
							if (wordleAnswers.Contains(userInput) || wordleExtras.Contains(userInput))
							{
								//copy the input to the grid
								for (int i = 0; i < WORD_LENGTH; i++)
								{
									//copy the letter into the grid spot
									displayGridArray[currentTry, i] = userInput.ElementAt(i);
								}

								//store the input to check that it is not repeated later. make the current try go up
								prevInputs[currentTry] = userInput;
								currentTry++;
							}
							else
							{
								//tell the user to try a real word input
								Console.WriteLine("Word not on list, please try again");
							}
						}
					}
					else if (userInput.Length < WORD_LENGTH)
					{
						//tell the user to try a longer input
						Console.WriteLine("Word too short, please try again");
					}
					else
					{
						//tell the user to try a shorter input
						Console.WriteLine("Word too long, please try again");
					}

					//prompt the user to get started if it is the first try 
					if (currentTry == 0)
					{
						//prompt the user to get started
						Console.WriteLine("Type a 5-letter word to get started");
					}

					//loop through printing each character from the guesses
					for (int i = 0; i < currentTry; i++)
					{
						//print this to make it like a grid
						Console.WriteLine("|—|—|+|—|—|");

						//loop through printing each character from the guess
						for (int j = 0; j < WORD_LENGTH; j++)
						{
							//print | as a seperator and print character from the guess
							Console.Write("|");
							CheckAndColour(answerWord, displayGridArray, j, i, letterColourCode);
						}

						//print | to close the end of the grid
						Console.WriteLine("|");
					}

					//print this to cap the bottom of the grid
					Console.WriteLine("|—|—|+|—|—|");

					//make new lines based on the number of guesses left
					for (int i = TRIES; i >= currentTry; i--)
					{
						//make 2 new lines
						Console.WriteLine("\n");
					}

					//loop through printing the alphabet + colour
					for (int i = 0; i < ALPHABET_SAMPLE_HEIGHT; i++)
					{
						//since the alphabet is 26 letters, print 2 spaces to cushion the last 6 letters
						if (i > 1)
						{
							//print two spaces
							Console.Write("".PadRight(2));
						}

						//loop through printing each line of the alphabet + colour
						for (int j = 0; j < ALPHABET_SAMPLE_WIDTH && j + i * ALPHABET_SAMPLE_WIDTH < ALPHABET_LENGTH; j++)
						{
							//set the text to black for contrast
							Console.ForegroundColor = ConsoleColor.Black;

							//colour the letter accordingly, based on where it is
							if (letterColourCode[j + i * ALPHABET_SAMPLE_WIDTH] == 1)
							{
								//green highlight to indicate the letter is in the correct space
								Console.BackgroundColor = ConsoleColor.Green;
							}
							else if (letterColourCode[j + i * ALPHABET_SAMPLE_WIDTH] == 2)
							{
								//yellow highlight to indicate the letter is in the word
								Console.BackgroundColor = ConsoleColor.Yellow;
							}
							else if (letterColourCode[j + i * ALPHABET_SAMPLE_WIDTH] == 3)
							{
								//grey highlight to indicate the letter is not in the word
								Console.BackgroundColor = ConsoleColor.DarkGray;
							}
							else
							{
								//white highlight to indicate the letter has not been tried yet
								Console.BackgroundColor = ConsoleColor.White;
							}

							//print the alphabet character
							Console.Write(alphabet[j + i * ALPHABET_SAMPLE_WIDTH]);

							//set the colours back to normal
							Console.ForegroundColor = ConsoleColor.White;
							Console.BackgroundColor = ConsoleColor.Black;
						}

						//make a new line
						Console.WriteLine();
					}

					//congratulate the user for winning if the answer is correct, or notify the user if they lost
					if (userInput == answerWord)
					{
						//print congrats and prompt continuation
						Console.WriteLine("Congrats! You win!");
						Console.WriteLine("Press enter when you are ready to continue");

						//increase the games played, streal
						gamesPlayed++;
						currentStreak++;

						//update the max streak if the current streak is larger
						if (currentStreak > maximumStreak)
						{
							//update the max streak
							maximumStreak = currentStreak;
						}

						//indicate what guess the win was on
						winSpread[currentTry - 1]++;
						
						//show the user their stats and save them
						StatsShower(gamesPlayed, currentStreak, maximumStreak, winSpread);
						WriteToStatsFile(gamesPlayed, currentStreak, maximumStreak, winSpread);

						//clear the console when the user proceeds
						Console.ReadLine();
						Console.Clear();

						//indicate the game is finished
						finishedGame = true;
					}
					else if (currentTry >= TRIES)
					{
						//tell the user they lost and what the word was, prompt continuation 
						Console.WriteLine("You lost! The word was: " + answerWord);

						//prompt continuation w/ colour
						Console.ForegroundColor = ConsoleColor.Blue;
						Console.WriteLine("Press enter when you are ready to continue");
						Console.ForegroundColor = ConsoleColor.White;

						//increase the games played and set the streak to 0
						gamesPlayed++;
						currentStreak = 0;

						//show the user their stats and save them
						StatsShower(gamesPlayed, currentStreak, maximumStreak, winSpread);
						WriteToStatsFile(gamesPlayed, currentStreak, maximumStreak, winSpread);

						//clear the console when the user proceeds
						Console.ReadLine();
						Console.Clear();

						//indicate the game is finished
						finishedGame = true;
					}
				}

				//print the logo and menu options
				Console.WriteLine("█   █  ███  ████  ████  █     █████");
				Console.WriteLine("█   █ █   █ █   █ █   █ █     █");
				Console.WriteLine("█ █ █ █   █ ████  █   █ █     ████");
				Console.WriteLine("██ ██ █   █ █   █ █   █ █     █");
				Console.WriteLine("█   █  ███  █   █ ████  █████ █████");
				Console.ForegroundColor = ConsoleColor.Black;
				Console.BackgroundColor = ConsoleColor.Green;
				Console.WriteLine("1 to play");
				Console.BackgroundColor = ConsoleColor.Yellow;
				Console.WriteLine("2 for instructions");
				Console.BackgroundColor = ConsoleColor.Cyan;
				Console.WriteLine("3 for stats");
				Console.BackgroundColor = ConsoleColor.Red;
				Console.WriteLine("7 to clear stats");
				Console.BackgroundColor = ConsoleColor.DarkGray;
				Console.WriteLine("0 to exit");
				Console.ForegroundColor = ConsoleColor.White;
				Console.BackgroundColor = ConsoleColor.Black;

				//read the user's menu option and clear the screen
				userInput = Console.ReadLine();
				Console.Clear();

				//depending on the user's input, play the game, look at instructions & stats, reset stats, &exit the game
				switch (userInput)
				{
					case PLAY:
						//reset the needed: grid array, try count, previous inputs, codes assinged to letters
						displayGridArray = new char[TRIES, WORD_LENGTH];
						currentTry = 0;
						prevInputs = new string[TRIES];
						letterColourCode = new byte[ALPHABET_LENGTH];

						//indicate a new game, get a new word
						answerWord = wordleAnswers[rng.Next(0, wordleAnswers.Count())];
						finishedGame = false;

						//tell the user that it's starting
						Console.WriteLine("Starting wordle!");
						break;
					case INSTRUCTIONS:
						//set the text black for contrast
						Console.ForegroundColor = ConsoleColor.Black;

						//show the colour and meaning of grey letters
						Console.BackgroundColor = ConsoleColor.DarkGray;
						Console.WriteLine("Guess a 5-letter word, grey letters mean they are not in the word");

						//show the colour and meaning of yellow letters
						Console.BackgroundColor = ConsoleColor.Yellow;
						Console.WriteLine("Yellow letters mean they are somewhere in the word, but not at that spot");

						//show the colour and meaning of green letters
						Console.BackgroundColor = ConsoleColor.Green;
						Console.WriteLine("Green letters mean they are in the correct spot");

						//explain the case of duplicate letters
						Console.BackgroundColor = ConsoleColor.DarkGray;
						Console.WriteLine("Duplicate letters in guesses will appear grey if there is no duplicate in the answer");

						//tell the user the game saves after every win
						Console.BackgroundColor = ConsoleColor.Green;
						Console.WriteLine("The game will save after every completion");

						//make the text colour normal again
						Console.ForegroundColor = ConsoleColor.White;
						Console.BackgroundColor = ConsoleColor.Black;
						break;
					case STATS:
						//show the stats only if at least one game has been played
						if (gamesPlayed > 0)
						{
							//show the player their stats
							StatsShower(gamesPlayed, currentStreak, maximumStreak, winSpread);
						}
						else
						{
							//prompt the user to play a game
							Console.WriteLine("Play at least 1 game first!");
						}
						break;
					case RESET_STATS:
						//get the user to type qwertyuiop to confirm data deletion
						Console.WriteLine("Type \"qwertyuiop\" to confirm data deletion");

						//if qwertyuiop is typed, reset the data & tell the player, else, say canceled and exit
						if (Console.ReadLine().Equals("qwertyuiop"))
						{
							//tell the player it's been reset
							Console.WriteLine("Data deleted");

							//reset the statistics and save to the file
							gamesPlayed = 0;
							currentStreak = 0;
							maximumStreak = 0;
							winSpread = new int[] { 0, 0, 0, 0, 0, 0 };
							WriteToStatsFile(gamesPlayed, currentStreak, maximumStreak, winSpread);
						}
						else
						{
							//tell the user it was canceled
							Console.WriteLine("Canceled");
						}
						break;
					case EXIT:
						//tell the user to have a nice day as they are exiting
						Console.WriteLine("Have an nice day!");

						//indicate to close the program
						exitGame = true;
						break;
					default:
						//prompt another input
						Console.WriteLine("Sorry, try another input please!");
						break;
				}

				//prompt the user to proceed
				Console.ForegroundColor = ConsoleColor.Blue;
				Console.WriteLine("Press enter to continue");
				Console.ForegroundColor = ConsoleColor.White;

				//clear the console when the user proceeds
				Console.ReadLine();
				Console.Clear();

				//if a game is being started, write this prompt
				if (!finishedGame)
				{
					//prompt the user to get started
					Console.WriteLine("Type a 5-letter word to get started");
				}
			}
		}

		//Pre: name of file read, list to store file data
		//Post: list with data added
		//Desc: takes the words or data from the files and adds them into lists for use inside the game
		private static void ReadWordFile(string fileName, List<string> fileWords)
		{
			//try to read the file, catch errors, and close the file
			try
			{
				//open the file to read
				inFile = File.OpenText(fileName);

				//read the words in the file until there are none left
				while (!inFile.EndOfStream)
				{
					//read the line in the file and add it to the list
					fileWords.Add(inFile.ReadLine());
				}
			}
			catch (FileNotFoundException fnf)
			{
				//file not found error feedback
				Console.WriteLine("ERROR: file not found." + fnf);
			}
			catch (EndOfStreamException eos)
			{
				//stream ended error feedback
				Console.WriteLine("ERROR: read past file." + eos);
			}
			catch (FormatException fe)
			{
				//bad format error feedback
				Console.WriteLine("ERROR: bad format." + fe);
			}
			catch (Exception e)
			{
				//general error feedback
				Console.WriteLine("ERROR: error?" + e);
			}
			finally
			{
				//if the file was being read, close reading
				if (inFile != null)
				{
					//close reading the file
					inFile.Close();
				}
			}
		}

		//Pre: number of games played, current streak, longest streak, distribution of wins
		//Post: nothing
		//Desc: write the statistical data to a file
		private static void WriteToStatsFile(int gamesPlayed, int streakNow, int streakLongest, int[] winDistribution)
		{
			//create/replace the stats file
			outFile = File.CreateText("PlayerStats.txt");

			//write played games and streak data
			outFile.WriteLine(gamesPlayed);
			outFile.WriteLine(streakNow);
			outFile.WriteLine(streakLongest);

			//write the win guess distribution
			foreach (int i in winDistribution)
			{
				//write the wins on that guess
				outFile.WriteLine(i);
			}

			//close writing to the file
			outFile.Close();
		}

		//Pre: the answer, the guess grid, the column of the letter, the row of the letter, array of codes associated to the letters
		//Post: nothing
		//Desc: prints the colours corresponding to the letters. helps in organization
		private static void CheckAndColour(string answer, char[,] grid, int index, int iteration, byte[] letterColourCode)
		{
			//write in black for contrast
			Console.ForegroundColor = ConsoleColor.Black;

			//select the colour of the letter according to  if it is in the right place, wrong place, or doesn't exist
			if (grid[iteration, index] == answer.ElementAt(index))
			{
				//green highlight to indicate the letter is in the correct space, and indicate the letter is green on the alphabet/keyboard
				Console.BackgroundColor = ConsoleColor.Green;
				AlphabetIndexFinder(grid, index, iteration, letterColourCode, GREEN_CODE);
			}
			else if (answer.Contains(grid[iteration, index]))
			{
				//check if the letter is a duplicate or not
				if (DuplicateLetterCheck(answer, grid, index, iteration) > 0)
				{
					//yellow highlight to indicate the letter is in the word, and indicate the letter is yellow on the alphabet/keyboard
					Console.BackgroundColor = ConsoleColor.Yellow;
					AlphabetIndexFinder(grid, index, iteration, letterColourCode, YELLOW_CODE);
				}
				else 
				{
					//grey highlight to indicate the letter is not in the word, and indicate the letter is grey on the alphabet/keyboard
					Console.BackgroundColor = ConsoleColor.DarkGray;
					AlphabetIndexFinder(grid, index, iteration, letterColourCode, GRAY_CODE);
				}
			}
			else
			{
				//grey highlight to indicate the letter is not in the word, and indicate the letter is grey on the alphabet/keyboard
				Console.BackgroundColor = ConsoleColor.DarkGray;
				AlphabetIndexFinder(grid, index, iteration, letterColourCode, GRAY_CODE);
			}

			//write the letter that was being checked
			Console.Write(grid[iteration, index]);

			//set the colours back to normal
			Console.ForegroundColor = ConsoleColor.White;
			Console.BackgroundColor = ConsoleColor.Black;
		}

		//Pre: the answer, the guess grid, the column of the letter, the row of the letter
		//Post: an integer indicating if there is a duplicate letter that should be yellow or not
		//Desc: assists in deciding if a letter should be yellow by taking the number of other duplicated letters
		//		in the answer, and subtracting that by the times it appears in the guess, will be yellow if >0
		private static int DuplicateLetterCheck(string answer, char[,] grid, int index, int iteration)
		{
			//keeps track of duplicates
			int dupeLetters = 0;

			//loop through each letter of the guess and answer and compare it to a letter in the guess
			for (int i = 0; i < WORD_LENGTH; i++)
			{
				//increase the count if the guess letter exists more than once in the answer
				if (answer.ElementAt(i) == grid[iteration, index] && answer.ElementAt(i) != grid[iteration, i])
				{
					//increase the duplicate count
					dupeLetters++;
				}

				//decrease the count if the letter exists once or more behind the letter in the input and isn't in the right place
				if (grid[iteration, i] == grid[iteration, index] && i < index && answer.ElementAt(i) != grid[iteration, i]) 
				{
					//decrease the duplicate count
					dupeLetters--;
				}
			}

			//return the sum of duplicates
			return dupeLetters;
		}

		//Pre: the guess grid, the column of the letter, the row of the letter, the array of the letter associated codes, the colour the letter is meant to be
		//Post: the array with the element updated if possible
		//Desc: find the index of the letter that should be coloured accordingly and indicate for colour if possible
		private static void AlphabetIndexFinder(char[,] grid, int index, int iteration, byte[] letterCode, byte numberCode)
		{
			//keeps track of the letter index
			byte indexTracker = 0;

			//loop through the alphabet to find the index
			for (byte i = 0; i < ALPHABET_LENGTH; i++)
			{
				//if the letter matches the letter in the alphabet, track the index
				if (grid[iteration, index] == alphabet[i])
				{
					//track the index and stop the loop to save time
					indexTracker = i;
					break;
				}
			}

			//see if the current colour code takes more priority or not
			if (letterCode[indexTracker] > numberCode || letterCode[indexTracker] == 0)
			{
				//replace the previous value with the new colour code
				letterCode[indexTracker] = numberCode;
			}
		}

		//Pre: number of games played, current streak, longest streak, distribution of wins
		//Post: 
		//Desc: show the user their raw and calculated stats
		private static void StatsShower(int gamesPlayed, int streakNow, int streakLongest, int[] winDistribution)
		{
			//these variables are the sums before division
			double preAverage = 0;
			double gamesWon = 0;

			//show games played, and streaks
			Console.WriteLine("Games played: " + gamesPlayed);
			Console.WriteLine("Current streak: " + streakNow);
			Console.WriteLine("Longest streak: " + streakLongest);

			//loop until the entire win distribution has been printed
			for (int i = 0; i < TRIES; i++)
			{
				//print the guess and how many wins there are later
				Console.Write("Won on guess " + (i + 1) + ", ");

				//colour of the boxes
				Console.BackgroundColor = ConsoleColor.Cyan;

				//print boxes based on the win distribution, the guess(es) with the most wins having 10 boxes
				for (int j = 0; j < Math.Ceiling(winDistribution[i] * MAX_BAR_LENGTH / Convert.ToDouble(winDistribution.Max())); j++)
				{
					//print the boxes
					Console.Write("[]");
				}

				//make the background black again, and print the times won on that guess
				Console.BackgroundColor = ConsoleColor.Black;
				Console.WriteLine(" " + winDistribution[i] + " times ");

				//sums needed to calculate the average and the win rate
				preAverage += winDistribution[i] * (i + 1);
				gamesWon += winDistribution[i];
			}

			//print and divide the sums to get the averages and win rate, and show the gmes won
			Console.WriteLine("Your total games won is: " + gamesWon);
			Console.WriteLine("Your average number of guesses is: " + (preAverage / gamesPlayed));
			Console.WriteLine("Your average number of winning guesses is: " + (preAverage / gamesWon));
			Console.WriteLine("Your win rate is: " + (gamesWon * 100 / gamesPlayed) + "%");
		}
	}
}
